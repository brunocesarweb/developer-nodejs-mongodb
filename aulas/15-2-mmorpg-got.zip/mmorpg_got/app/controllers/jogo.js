module.exports.jogo = function(application, req, res){
	res.render('jogo');
}